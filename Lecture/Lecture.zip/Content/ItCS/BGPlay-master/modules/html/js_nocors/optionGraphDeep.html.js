addTemplateContent('optionGraphDeep.html', '<div style="border: 1px solid #C0C0C0; padding: 0px 5px 5px 10px; margin-bottom: 5px;">'+
'    <label for="optionGraphDeep">Hide AS if reached by paths longer than:</label>'+
'    <input type="text" class="optionGraphDeepValue" value="1" style="border: 0; color: #f6931f; background:transparent; width:30px;" />'+
'    <div class="graphDeepSlider" style="width: 200px;"></div>'+
'</div>');