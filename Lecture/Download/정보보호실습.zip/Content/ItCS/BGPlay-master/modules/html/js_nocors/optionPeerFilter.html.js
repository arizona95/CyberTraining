addTemplateContent('optionPeerFilter.html', '<div style="border:1px solid #C0C0C0; padding: 0px 5px 5px 10px;margin-bottom:5px;"> ' +
'<label>Only show data from Collector Peer(s):</label> ' +
'<input type="text" class="cpFilter" value="{{collectorPeers}}" placeholder="3333,7575"/>' +
'</div>');