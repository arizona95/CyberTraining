addTemplateContent('optionLinkWeight.html', '<div style="border:1px solid #C0C0C0; padding: 0px 5px 5px 10px;margin-bottom:5px;">' +
    '    <label for="optionLinkWeight">Only show AS links if seen by # RIS peers:</label>' +
    '    <input type="text" class="optionLinkWeightValue" value="1" style="border: 0; color: #f6931f; background: transparent; width: 30px;" />' +
    '    <div class="optionLinkWeightSlider" style="width: 200px;"></div>' +
    '</div>');